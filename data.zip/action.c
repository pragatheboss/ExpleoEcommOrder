Action()
{

	web_set_sockets_option("SSL_VERSION", "AUTO");

	web_url("prestashop-dublin-production-658025956.eu-west-1.elb.amazonaws.com", 
		"URL=http://prestashop-dublin-production-658025956.eu-west-1.elb.amazonaws.com/", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t1.inf", 
		"Mode=HTML", 
		LAST);

	web_url("seed", 
		"URL=https://clientservices.googleapis.com/chrome-variations/seed?osname=win&channel=stable&milestone=102", 
		"TargetFrame=", 
		"Resource=0", 
		"Referer=", 
		"Snapshot=t2.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=http://prestashop-dublin-production-658025956.eu-west-1.elb.amazonaws.com/themes/classic/assets/css/19c1b868764c0e4d15a45d3f61250488.woff2", "Referer=http://prestashop-dublin-production-658025956.eu-west-1.elb.amazonaws.com/themes/classic/assets/css/theme.css", ENDITEM, 
		"Url=http://prestashop-dublin-production-658025956.eu-west-1.elb.amazonaws.com/themes/classic/assets/css/570eb83859dc23dd0eec423a49e147fe.woff2", "Referer=http://prestashop-dublin-production-658025956.eu-west-1.elb.amazonaws.com/themes/classic/assets/css/theme.css", ENDITEM, 
		"Url=http://prestashop-dublin-production-658025956.eu-west-1.elb.amazonaws.com/themes/classic/assets/css/199038f07312bfc6f0aabd3ed6a2b64d.woff2", "Referer=http://prestashop-dublin-production-658025956.eu-west-1.elb.amazonaws.com/themes/classic/assets/css/theme.css", ENDITEM, 
		LAST);

	return 0;
}